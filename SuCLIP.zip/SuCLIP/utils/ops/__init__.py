# -*- coding: utf-8 -*-
from .array_ops import *
from .tensor_ops import *
