import numpy as np
import torch
from torch import nn
import math
import scipy.stats as st
from methods.base.base_ops import LayerNorm2d, resize_to
from methods.ovcoser.layers import ConvMlp
import torch.nn.functional as F
from einops import rearrange, repeat


def MASK_POOL(image_feat, mask):
    obj_embs = mask * resize_to(image_feat, tgt_hw=mask.shape[-2:])
    obj_embs = obj_embs.sum((2, 3)) / mask.sum((2, 3))  # b d
    return obj_embs


class Attention(nn.Module):
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5

        self.q_proj = nn.Linear(dim, dim, bias=qkv_bias)
        self.k_proj = nn.Linear(dim, dim, bias=qkv_bias)
        self.v_proj = nn.Linear(dim, dim, bias=qkv_bias)

        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, q, k, v):
        B, N, C = q.shape
        assert k.shape == v.shape
        B, M, C = k.shape
        q = self.q_proj(q).reshape(B, N, self.num_heads, C // self.num_heads)
        k = self.k_proj(k).reshape(B, M, self.num_heads, C // self.num_heads)
        v = self.v_proj(v).reshape(B, M, self.num_heads, C // self.num_heads)

        attn = torch.einsum('bnkc,bmkc->bknm', q, k) * self.scale

        attn = attn.softmax(dim=-1)

        x = torch.einsum('bknm,bmkc->bnkc', attn, v).reshape(B, N, C)

        x = self.proj(x)
        x = self.proj_drop(x)
        return x


class TextImgMatchBlock(nn.Module):
    def __init__(self, feat_dim, guide_dim, num_heads=4):
        super().__init__()
        self.feat_dim = feat_dim
        self.guide_dim = guide_dim

        self.guide_norm = nn.LayerNorm(guide_dim)
        self.feat_norm = LayerNorm2d(feat_dim)

        self.num_heads = num_heads
        self.attn_scale = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.g_proj = nn.Linear(guide_dim, feat_dim, bias=False)
        self.qkv_proj = nn.Conv2d(feat_dim, 3 * feat_dim, 1, bias=False)
        self.o_proj = nn.Conv2d(feat_dim, feat_dim, 1, bias=True)

        self.norm_ffn = ConvMlp(feat_dim, feat_dim)
        self.self_attention = Attention(feat_dim)
        self.norm1 = nn.LayerNorm(feat_dim)

    def masked_pooling(self, image_feat, mask):
        obj_embs = mask * resize_to(image_feat, tgt_hw=mask.shape[-2:])
        obj_embs = obj_embs.sum((2, 3)) / mask.sum((2, 3))
        return obj_embs

    def forward(self, img_feats, cls_embs, cls_logits=None, seg_logits=None, verbose=False):
        normed_img_feats = self.feat_norm(img_feats)  
        B, C, H, W = normed_img_feats.shape
        b = 1
        normed_cls_embs = self.guide_norm(cls_embs) 
        g = self.g_proj(normed_cls_embs)  
        g = g.expand(b, -1, -1)  
        g_q = g_k = g_v = self.norm1(g)
        g = g + self.self_attention(g_q, g_k, g_v)
        g = g.squeeze(0)
        qkv = self.qkv_proj(normed_img_feats)  
        g = rearrange(g, "nc (nh hd) -> nc nh hd", nh=self.num_heads) 
        qkv = rearrange(qkv, "b (ng nh hd) h w -> ng b nh hd (h w)", ng=3, nh=self.num_heads)  
        q, k, v = qkv.unbind(0)  
        guide_map = torch.einsum("nhd, bhdl -> bhnl", F.normalize(g, dim=-1), F.normalize(q, dim=-2)) 
        #
        guide_map = guide_map - guide_map.min(dim=-1, keepdim=True).values
        guide_map = guide_map / guide_map.max(dim=-1, keepdim=True).values

        guide_map = (guide_map.softmax(dim=2) * guide_map).sum(dim=2).unsqueeze(2)
        v = guide_map * v  
        hw_norm_q = F.normalize(q, dim=-1) 
        hw_norm_k = F.normalize(k, dim=-1)  
        attn = hw_norm_q @ hw_norm_k.transpose(-1, -2) 
        attn = self.attn_scale * attn  
        qkv = attn.softmax(dim=-1) @ v  
        qkv = rearrange(qkv, "b nh hd (h w) -> b (nh hd) h w", h=H, w=W)  
        img_feats = img_feats + self.o_proj(qkv)  
        img_feats = img_feats + self.norm_ffn(img_feats)  

        return img_feats


class StructureEnhancementBlock(nn.Module):
    def __init__(self, dim, num_heads=4):
        super().__init__()
        self.dim = dim
        self.q_norm = LayerNorm2d(dim)
        self.kv_norm = LayerNorm2d(dim)

        self.num_heads = num_heads
        self.attn_scale = nn.Parameter(torch.zeros(num_heads, 1, 1))

        self.q_proj = nn.Conv2d(dim, dim, 1, bias=False)
        self.kv_proj = nn.Conv2d(dim, 2 * dim, 1, bias=False)
        self.o_proj = nn.Conv2d(dim, dim, 1, bias=True)

        self.norm_ffn = ConvMlp(dim, dim)

    def forward(self, img_feat, aux_feats=None):
        assert isinstance(aux_feats, (list, tuple))
        # B,C,H,W
        B, C, H, W = img_feat.shape
        q = self.q_norm(img_feat)
        kv = self.kv_norm(torch.cat(aux_feats, dim=0)) 

        q = self.q_proj(q)
        kv = self.kv_proj(kv)
        q = rearrange(q, "b (nh hd) h w -> b nh hd (h w)", nh=self.num_heads)
        kv = rearrange(kv, "b (ng nh hd) h w -> ng b nh hd (h w)", ng=2, nh=self.num_heads)
        k, v = kv.unbind(0)

        hw_norm_q = F.normalize(q, dim=-1)  
        hw_norm_k = F.normalize(k, dim=-1)  
        if len(aux_feats) == 1:
            attn = hw_norm_q @ hw_norm_k.transpose(-1, -2)  
            qkv = attn.softmax(dim=-1) @ v  
        else:
            assert len(aux_feats) == 2, len(aux_feats)
            hw_norm_tex_k, hw_norm_dep_k = hw_norm_k.chunk(2, dim=0)  
            tex_v, dep_v = v.chunk(2, dim=0)  

            tex_attn = hw_norm_q @ hw_norm_tex_k.transpose(-1, -2)  
            dep_attn = hw_norm_q @ hw_norm_dep_k.transpose(-1, -2) 
            tex_qkv = tex_attn.softmax(dim=-1) @ tex_v  
            dep_qkv = dep_attn.softmax(dim=-1) @ dep_v  
            qkv = self.attn_scale.sigmoid() * tex_qkv + (1 - self.attn_scale.sigmoid()) * dep_qkv
        qkv = rearrange(qkv, "b nh hd (h w) -> b (nh hd) h w", h=H, w=W)

        img_feat = img_feat + self.o_proj(qkv)
        img_feat = img_feat + self.norm_ffn(img_feat)
        return img_feat


def gkern(kernlen=16, nsig=3):
    interval = (2 * nsig + 1.) / kernlen
    x = np.linspace(-nsig - interval / 2., nsig + interval / 2., kernlen + 1)
    kern1d = np.diff(st.norm.cdf(x))
    kernel_raw = np.sqrt(np.outer(kern1d, kern1d))
    kernel = kernel_raw / kernel_raw.sum()
    return kernel


def min_max_norm(in_):
    max_ = in_.max(3)[0].max(2)[0].unsqueeze(2).unsqueeze(3).expand_as(in_)
    min_ = in_.min(3)[0].min(2)[0].unsqueeze(2).unsqueeze(3).expand_as(in_)
    in_ = in_ - min_
    return in_.div(max_ - min_ + 1e-8)


class Refine(nn.Module):
    def __init__(self):
        super(Refine, self).__init__()
        gaussian_kernel = np.float32(gkern(31, 4))
        gaussian_kernel = gaussian_kernel[np.newaxis, np.newaxis, ...]
        self.gaussian_kernel = nn.Parameter(torch.from_numpy(gaussian_kernel))

    def forward(self, attention, x):
        if attention.size != x.size:
            attention = F.interpolate(attention, size=x.size()[2:], mode='bilinear', align_corners=True)
        attention = attention.sigmoid()
        soft_attention = F.conv2d(attention, self.gaussian_kernel, padding=15)
        soft_attention = min_max_norm(soft_attention)
        x = torch.mul(x, soft_attention.max(attention))
        return x


def get_grid_index(init_size, map_size, device):

    H_init, W_init = init_size
    H, W = map_size
    idx = torch.arange(H * W, device=device).reshape(1, 1, H, W)
    idx = F.interpolate(idx.float(), [H_init, W_init], mode='nearest').long()
    return idx.flatten()


def token2map(token_dict):
    x = token_dict['x']
    H, W = token_dict['map_size']
    H_init, W_init = token_dict['init_grid_size']
    idx_token = token_dict['idx_token']
    B, N, C = x.shape
    N_init = H_init * W_init
    device = x.device

    if N_init == N and N == H * W:
        return x.reshape(B, H, W, C).permute(0, 3, 1, 2).contiguous()
    idx_hw = get_grid_index(
        [H_init, W_init], [H, W], device=device)[None, :].expand(B, -1)
    idx_batch = torch.arange(B, device=device)[:, None].expand(B, N_init)
    value = x.new_ones(B * N_init)

    if N_init < N * H * W:
        idx_hw = idx_hw + idx_batch * H * W
        idx_tokens = idx_token + idx_batch * N
        coor = torch.stack([idx_hw, idx_tokens], dim=0).reshape(2, B * N_init)

        with torch.cuda.amp.autocast(enabled=False):
            value = value.detach().float()

            A = torch.sparse.FloatTensor(coor, value, torch.Size([B * H * W, B * N]))

            all_weight = A @ x.new_ones(B * N, 1).type(torch.float32) + 1e-6
            value = value / all_weight[idx_hw.reshape(-1), 0]

            A = torch.sparse.FloatTensor(coor, value, torch.Size([B * H * W, B * N]))

            x_out = A @ x.reshape(B * N, C).type(torch.float32)

    else:

        coor = torch.stack([idx_batch, idx_hw, idx_token], dim=0).reshape(3, B * N_init)
        A = torch.sparse.FloatTensor(coor, value, torch.Size([B, H * W, N])).to_dense()
        A = A / (A.sum(dim=-1, keepdim=True) + 1e-6)

        x_out = A @ x  

    x_out = x_out.type(x.dtype)
    x_out = x_out.reshape(B, H, W, C).permute(0, 3, 1, 2).contiguous()
    return x_out


def map2token(feature_map, token_dict):
    idx_token = token_dict['idx_token']
    N = token_dict['token_num']
    H_init, W_init = token_dict['init_grid_size']
    N_init = H_init * W_init

    agg_weight = None

    B, C, H, W = feature_map.shape
    device = feature_map.device

    if N_init == N and N == H * W:
       
        return feature_map.flatten(2).permute(0, 2, 1).contiguous()

    idx_hw = get_grid_index(
        [H_init, W_init], [H, W], device=device)[None, :].expand(B, -1)

    idx_batch = torch.arange(B, device=device)[:, None].expand(B, N_init)
    if agg_weight is None:
        value = feature_map.new_ones(B * N_init)
    else:
        value = agg_weight.reshape(B * N_init).type(feature_map.dtype)

   
    if N_init < N * H * W:
       
        idx_token = idx_token + idx_batch * N
        idx_hw = idx_hw + idx_batch * H * W
        indices = torch.stack([idx_token, idx_hw], dim=0).reshape(2, -1)

     
        with torch.cuda.amp.autocast(enabled=False):
            value = value.detach().float()
            A = torch.sparse_coo_tensor(indices, value, (B * N, B * H * W))
            all_weight = A @ torch.ones(
                [B * H * W, 1], device=device, dtype=torch.float32) + 1e-6
            value = value / all_weight[idx_token.reshape(-1), 0]
            A = torch.sparse_coo_tensor(indices, value, (B * N, B * H * W))
            out = A @ feature_map. \
                permute(0, 2, 3, 1).contiguous().reshape(B * H * W, C).float()
    else:
        indices = torch.stack([idx_batch, idx_token, idx_hw], dim=0).reshape(3, -1)
        value = value.detach() 
        A = torch.sparse_coo_tensor(indices, value, (B, N, H * W)).to_dense()
        A = A / (A.sum(dim=-1, keepdim=True) + 1e-6)

        out = A @ feature_map.permute(0, 2, 3, 1).reshape(B, H * W, C).contiguous()

    out = out.type(feature_map.dtype)
    out = out.reshape(B, N, C)
    return out


def cluster_dpc_knn(token_dict, cluster_num, k=5, token_mask=None):
    with torch.no_grad():
        x = token_dict['x']
        B, N, C = x.shape

        dist_matrix = torch.cdist(x, x) / (C ** 0.5)

        if token_mask is not None:
            token_mask = token_mask > 0
            dist_matrix = dist_matrix * token_mask[:, None, :] + \
                          (dist_matrix.max() + 1) * (~token_mask[:, None, :])

      
        dist_nearest, index_nearest = torch.topk(dist_matrix, k=k, dim=-1, largest=False)

        density = (-(dist_nearest ** 2).mean(dim=-1)).exp()
      
        density = density + torch.rand(
            density.shape, device=density.device, dtype=density.dtype) * 1e-6

        if token_mask is not None:
            density = density * token_mask

        mask = density[:, None, :] > density[:, :, None]
        mask = mask.type(x.dtype)
        dist_max = dist_matrix.flatten(1).max(dim=-1)[0][:, None, None]
        dist, index_parent = (dist_matrix * mask + dist_max * (1 - mask)).min(dim=-1)

        score = dist * density
        _, index_down = torch.topk(score, k=cluster_num, dim=-1)

        dist_matrix = index_points(dist_matrix, index_down)

        idx_cluster = dist_matrix.argmin(dim=1)

        idx_batch = torch.arange(B, device=x.device)[:, None].expand(B, cluster_num)
        idx_tmp = torch.arange(cluster_num, device=x.device)[None, :].expand(B, cluster_num)
        idx_cluster[idx_batch.reshape(-1), index_down.reshape(-1)] = idx_tmp.reshape(-1)

    return idx_cluster, cluster_num


def index_points(points, idx):
    device = points.device
    B = points.shape[0]
    view_shape = list(idx.shape)
    view_shape[1:] = [1] * (len(view_shape) - 1)
    repeat_shape = list(idx.shape)
    repeat_shape[0] = 1
    batch_indices = torch.arange(B, dtype=torch.long).to(device).view(view_shape).repeat(repeat_shape)
    new_points = points[batch_indices, idx, :]
    return new_points


def merge_tokens(token_dict, idx_cluster, cluster_num, token_weight=None):
    x = token_dict['x']
    idx_token = token_dict['idx_token']
    agg_weight = token_dict['agg_weight']

    B, N, C = x.shape
    if token_weight is None:
        token_weight = x.new_ones(B, N, 1)

    idx_batch = torch.arange(B, device=x.device)[:, None]
    idx = idx_cluster + idx_batch * cluster_num

    all_weight = token_weight.new_zeros(B * cluster_num, 1)
    all_weight.index_add_(dim=0, index=idx.reshape(B * N),
                          source=token_weight.reshape(B * N, 1))
    all_weight = all_weight + 1e-6
    norm_weight = token_weight / all_weight[idx]

    x_merged = x.new_zeros(B * cluster_num, C)
    source = x * norm_weight
    x_merged.index_add_(dim=0, index=idx.reshape(B * N),
                        source=source.reshape(B * N, C).type(x.dtype))
    x_merged = x_merged.reshape(B, cluster_num, C)

    idx_token_new = index_points(idx_cluster[..., None], idx_token).squeeze(-1)
    weight_t = index_points(norm_weight, idx_token)
    agg_weight_new = agg_weight * weight_t
    agg_weight_new / agg_weight_new.max(dim=1, keepdim=True)[0]

    out_dict = {}
    out_dict['x'] = x_merged
    out_dict['token_num'] = cluster_num
    out_dict['map_size'] = token_dict['map_size']
    out_dict['init_grid_size'] = token_dict['init_grid_size']
    out_dict['idx_token'] = idx_token_new
    out_dict['agg_weight'] = agg_weight_new
    return out_dict


class TokenConv(nn.Conv2d):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        groups = kwargs['groups'] if 'groups' in kwargs.keys() else 1
        self.skip = nn.Conv1d(in_channels=kwargs['in_channels'],
                              out_channels=kwargs['out_channels'],
                              kernel_size=1, bias=False,
                              groups=groups)

    def forward(self, token_dict):
        x = token_dict['x']
        x = self.skip(x.permute(0, 2, 1)).permute(0, 2, 1)
        x_map = token2map(token_dict)
        x_map = super().forward(x_map)
        x = x + map2token(x_map, token_dict)
        return x


class CTM(nn.Module):
    def __init__(self, embed_dim, dim_out, sample_ratio, k=5):
        super().__init__()
        self.sample_ratio = sample_ratio
        self.dim_out = dim_out
        self.conv = TokenConv(in_channels=embed_dim, out_channels=dim_out, kernel_size=3, stride=2, padding=1)
        self.norm = nn.LayerNorm(self.dim_out)
        self.score = nn.Linear(self.dim_out, 1)
        self.k = k

    def forward(self, token_dict):
        token_dict = token_dict.copy()
        x = self.conv(token_dict)
        x = self.norm(x)
        token_score = self.score(x)
        token_weight = token_score.exp()

        token_dict['x'] = x
        B, N, C = x.shape
        token_dict['token_score'] = token_score

        cluster_num = max(math.ceil(N * self.sample_ratio), 1)
        idx_cluster, cluster_num = cluster_dpc_knn(
            token_dict, cluster_num, self.k)
        down_dict = merge_tokens(token_dict, idx_cluster, cluster_num, token_weight)

        H, W = token_dict['map_size']
        H = math.floor((H - 1) / 2 + 1)
        W = math.floor((W - 1) / 2 + 1)
        down_dict['map_size'] = [H, W]

        map = token2map(token_dict)
        return map


class MLP(nn.Module):
    def __init__(self, dim, factor):
        super().__init__()

        self.mlp = nn.Sequential(nn.Conv2d(dim, dim // factor, 1, bias=False),
                                 nn.BatchNorm2d(dim // factor),
                                 nn.ReLU(),
                                 nn.Conv2d(dim // factor, dim, 1, bias=False),
                                 )

    def forward(self, x):
        return self.mlp(x)


class CSM(nn.Module):
    def __init__(self, hidden_dim, factor):
        super().__init__()
        self.mlp = nn.Sequential(MLP(hidden_dim, factor),
                                 nn.Sigmoid())

    def forward(self, x):
        x_avg = x.mean(dim=[2, 3], keepdim=True)
        x_w = self.mlp(x_avg).sigmoid()
        return x + x * x_w
