from .ovcoser.suclip import SuCLIP
