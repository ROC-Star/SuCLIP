from collections import OrderedDict
import torch
from open_clip import tokenize
from torch import nn


CAMO_PROMPTS = "A camouflaged photo of the {}."

def get_prompt_template_by_name(name):
    if name == "camoprompts":
        template_set = CAMO_PROMPTS
    else:
        raise NotImplementedError(template_set)
    return template_set


class PromptLearner(nn.Module):
    def __init__(self, classnames, clip_model, template_init, ):
        super().__init__()
        n_cls = len(classnames)
        n_ctx = 5
        ctx_init = template_init
        dtype = clip_model.transformer.get_cast_dtype()
        ctx_dim = clip_model.ln_final.weight.shape[0]
        vis_dim = ctx_dim
        device_id = 0
        device = torch.device("cuda:2".format(device_id) if torch.cuda.is_available() else "cpu")
        clip_model = clip_model.to(device)

        if ctx_init:
            ctx_init = ctx_init.replace("_", " ")
            n_ctx = len(ctx_init.split(" "))

            prompt = tokenize(ctx_init).to(device)

            with torch.no_grad():
                embedding = clip_model.token_embedding(prompt).type(dtype).to(device)
            ctx_vectors = embedding[0, 1: 1 + n_ctx, :]
            prompt_prefix, prompt_suffix = ctx_init.split("{}")
        else:
            ctx_vectors = torch.empty(n_ctx, ctx_dim, dtype=dtype).to(device)
            nn.init.normal_(ctx_vectors, std=0.02)
            prompt_prefix = " ".join(["X"] * n_ctx)

        print(f'Initial context_prefix: "{prompt_prefix,}"')
        print(f"Number of context words (tokens): {n_ctx}")

        self.ctx = nn.Parameter(ctx_vectors)

        self.meta_net = nn.Sequential(OrderedDict([
            ("linear1", nn.Conv1d(1, vis_dim // 16, kernel_size=3, stride=1, padding=1)),
            ("relu", nn.ReLU(inplace=True)),
            ("linear2", nn.Conv1d(vis_dim // 16, 1, kernel_size=3, stride=1, padding=1))
        ])).to(device)

        classnames = [name.replace("{}", " ") for name in classnames]
        name_lens = [len(tokenize(name)) for name in classnames]

        prompts = [prompt_prefix + " " + name for name in classnames]
        print("prompts:", prompts)

        tokenized_prompts = torch.cat([tokenize(p) for p in prompts]).to(device)  
        with torch.no_grad():
            embedding = clip_model.token_embedding(tokenized_prompts).type(dtype)

        self.register_buffer("token_prefix", embedding[:, :1, :])  
        self.register_buffer("token_suffix", embedding[:, 1 + n_ctx:, :]) 

        self.n_cls = n_cls
        self.n_ctx = n_ctx
        self.tokenized_prompts = tokenized_prompts
        self.name_lens = name_lens

    def construct_prompts(self, ctx, prefix, suffix, label=None):

        if label is not None:
            prefix = prefix[label]
            suffix = suffix[label]

        prompts = torch.cat(
            [
                prefix,  
                ctx,  
                suffix, 
            ],
            dim=1,
        )

        return prompts

    def forward(self, im_features):
        prefix = self.token_prefix
        suffix = self.token_suffix
        ctx = self.ctx 
        im_features = im_features.unsqueeze(1)  
        bias = self.meta_net(im_features)
        ctx = ctx.unsqueeze(0)  
        ctx_shifted = ctx + bias  
        prompts = []
        for ctx_shifted_i in ctx_shifted:
            ctx_i = ctx_shifted_i.unsqueeze(0).expand(self.n_cls, -1, -1)
            pts_i = self.construct_prompts(ctx_i, prefix, suffix)
            prompts.append(pts_i)
        prompts = torch.stack(prompts)
        return prompts
