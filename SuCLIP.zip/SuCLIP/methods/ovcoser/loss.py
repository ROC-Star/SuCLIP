from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

import torch
import torch.nn.functional as F
from torch import Tensor

def DiceLoss(inputs, targets):
    #print(inputs.shape, targets.shape)
    # bce = F.binary_cross_entropy(inputs, targets)
    inter = (inputs * targets).sum()
    eps = 1e-5
    dice = (2 * inter + eps) / (inputs.sum() + targets.sum() + eps)
    #print(bce.item(), inter.item(), inputs.sum().item(), dice.item())
    return 1 - dice


def seg_loss(logits, mask):
    weit = 1 + 5 * torch.abs(F.avg_pool2d(mask, kernel_size=31, stride=1, padding=15) - mask)
    wbce = F.binary_cross_entropy_with_logits(logits, mask, reduction="none")
    wbce = (weit * wbce).sum(dim=(2, 3)) / weit.sum(dim=(2, 3))

    pred = torch.sigmoid(logits)
    inter = ((pred * mask) * weit).sum(dim=(2, 3))
    union = ((pred + mask) * weit).sum(dim=(2, 3))
    wiou = 1 - (inter + 1) / (union - inter + 1)
    return (wbce + wiou).mean()


def soft_dice_loss(prob, edge, smooth=1, p=2):
    prob = prob.reshape(prob.shape[0], -1)
    edge = edge.reshape(edge.shape[0], -1)

    num = (prob * edge).sum(dim=1) * 2 + smooth
    den = (prob.pow(p) + edge.pow(p)).sum(dim=1) + smooth
    loss = 1 - num / den
    return loss.mean()


def edge_dice_loss(logits, edge, smooth=1, p=2):
    if logits.shape[-2:] != edge.shape[-2:]:
        logits = F.interpolate(logits, size=edge.shape[-2:], mode="bilinear", align_corners=False)

    prob = logits.sigmoid()
    return soft_dice_loss(prob, edge, smooth, p)