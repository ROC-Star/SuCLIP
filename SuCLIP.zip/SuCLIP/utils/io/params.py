# -*- coding: utf-8 -*-

import os

import torch
from torch import nn


def save_weight(save_path: str, model: nn.Module, suffix: str = ""):
    if suffix:
        save_path_wo_suffix, ori_suffix = os.path.splitext(save_path)
        save_path = save_path_wo_suffix + suffix + ori_suffix

    print(f"Saving weight '{save_path}'")
    model_state = model.module.state_dict() if hasattr(model, "module") else model.state_dict()
    torch.save(model_state, save_path)
    print(f"Saved weight '{save_path}' " f"(only contain the net's weight)")


def load_weight(load_path: str, model: nn.Module, strict=True, prefix="module."):
    # assert os.path.exists(load_path), load_path
    params = torch.load(load_path, map_location="cpu")
    # """
    # 由于Prompt_learner中的提示词前缀和后缀是，训练和测试的类别数不同，所以删除这两个参数
    # """
    if "clip.PROMPT_L.token_prefix" and "clip.PROMPT_L.token_suffix" in params:
        del params['clip.PROMPT_L.token_prefix']
        del params['clip.PROMPT_L.token_suffix']
    if "cod_head_score.0.ln.weight" in params:
        del params['cod_head_score.0.ln.weight']
        del params['cod_head_score.0.ln.bias']
        del params['cod_head_score.0.conv.weight']
        del params['cod_head_score.1.weight']
        del params['cod_head_score.1.bias']
    params = {k[len(prefix):] if k.startswith(prefix) else k: v for k, v in params.items()}
    model.load_state_dict(params, strict=strict)
    print(f"Loaded the weight (only contains the net's weight) from {load_path}")
