import open_clip
import torch
import torch.nn.functional as F
from loguru import logger
from open_clip import OPENAI_DATASET_MEAN, OPENAI_DATASET_STD
from torch import nn
from methods.ovcoser.prompts import get_prompt_template_by_name, PromptLearner


class CLIP(nn.Module):
    def __init__(
            self,
            classnames,
            model_name="convnext_xxlarge",
            pretrained="laion2b_s34b_b82k_augreg_soup",
            template_set="camoprompts",

    ):
        super().__init__()
        self.clip_model, _, self.preprocess_val = open_clip.create_model_and_transforms(
            model_name, pretrained=pretrained
        )

        self.mean = OPENAI_DATASET_MEAN
        self.std = OPENAI_DATASET_STD
        self.text_tokenizer = open_clip.get_tokenizer(model_name)  

        self.template_set = get_prompt_template_by_name(template_set) 
        logger.info(
            f"Create the CLIP ({model_name + '-' + pretrained}) with template_set {self.template_set}")

        model_name = model_name.lower()
        assert "convnext_" in model_name
        self.model_type = "convnext"
        self.feat_chans = [384, 384, 768, 1536, 3072]

        self.dim_latent = self.clip_model.text_projection.shape[-1]
        self.out_strides = {"stem": 2, "res2": 4, "res3": 8, "res4": 16, "res5": 32, "emb": -1}
        self.out_chans = {
            "stem": self.feat_chans[0],
            "res2": self.feat_chans[1],
            "res3": self.feat_chans[2],
            "res4": self.feat_chans[3],
            "res5": self.feat_chans[4],
            "emb": self.dim_latent,
        }
        self.PROMPT_L = PromptLearner(classnames=classnames, clip_model=self.clip_model,
                                      template_init=self.template_set
                                      )
        self.text_feature_buffer = {}


    def output_shape(self):
        return {
            name: dict(channels=self.out_chans[name], stride=self.out_strides[name])
            for name in ["stem", "res2", "res3", "res4", "res5", "emb"]
        }

    @property
    def device(self):
        for param in self.clip_model.parameters():
            return param.device

    @torch.no_grad()
    def get_text_embs(self, text_list, normalize=True):
        self.eval()
        text_tokens = self.text_tokenizer(text_list).cuda()
        cast_dtype = self.clip_model.transformer.get_cast_dtype()
        x = self.clip_model.token_embedding(text_tokens).to(cast_dtype) 
        x = x + self.clip_model.positional_embedding.to(cast_dtype) 
        x = x.permute(1, 0, 2) 
        x = self.clip_model.transformer(x, attn_mask=self.clip_model.attn_mask)
        x = x.permute(1, 0, 2) 
        x = self.clip_model.ln_final(x)  

        text_embs = x[torch.arange(x.shape[0]), text_tokens.argmax(dim=-1)] @ self.clip_model.text_projection

        if normalize:
            text_embs = F.normalize(text_embs, dim=-1)
        return text_embs

    @torch.no_grad()
    def inference_get_text_emb(self, text_list):
        self.eval()
        self.clip_model.transformer.batch_first = False 
        temp = self.template_set
        prompts = [temp.format(c.replace("{}", " ")) for c in text_list]
        print(f"Prompts: {prompts}")
        prompts = torch.cat([self.text_tokenizer(p) for p in prompts]).to(self.device)
        with torch.no_grad():
            cast_dtype = self.clip_model.transformer.get_cast_dtype()
            x = self.clip_model.token_embedding(prompts).to(cast_dtype)
            x = x + self.clip_model.positional_embedding.to(cast_dtype)
            x = x.permute(1, 0, 2) 
            attn_mask = self.clip_model.attn_mask
            x = self.clip_model.transformer(x, attn_mask=attn_mask)
            x = x.permute(1, 0, 2)  
            x = self.clip_model.ln_final(x)  
            text_emb = x[torch.arange(x.shape[0]), prompts.argmax(dim=-1)] @ self.clip_model.text_projection
            text_embs = []
            text_embs.append(text_emb)
            text_embs = torch.stack(text_embs, dim=1) 
            text_embs /= text_embs.norm(dim=-1, keepdim=True)
            text_embs = text_embs.mean(1)
            text_embs /= text_embs.norm(dim=-1, keepdim=True)
        return text_embs 

    def text_encoder(self, prompt_i, tokenized_prompts):
        cast_dtype = self.clip_model.transformer.get_cast_dtype()
        x = prompt_i + self.clip_model.positional_embedding.to(cast_dtype)  
        x = x.permute(1, 0, 2)
        attn_mask = self.clip_model.attn_mask
        x = self.clip_model.transformer(x, attn_mask=attn_mask)
        x = x.permute(1, 0, 2)
        x = self.clip_model.ln_final(x)
        tokenized_prompts = tokenized_prompts
        text_emb = x[torch.arange(x.shape[0]), tokenized_prompts.argmax(dim=-1)] @ self.clip_model.text_projection
        return text_emb

    @torch.no_grad()
    def get_text_embs_by_template(self, text_list, imag_fea, with_trainable_params):
        self.eval()
        self.clip_model.transformer.batch_first = False 
        if with_trainable_params:
            prompts = self.PROMPT_L(imag_fea) 
            tokenized_prompts = self.PROMPT_L.tokenized_prompts 
            text_embs = []
            for prompt_i in prompts:
                text_emb = self.text_encoder(prompt_i, tokenized_prompts)
                text_embs.append(text_emb)
            text_embs = torch.stack(text_embs, dim=0)  
            text_embs /= text_embs.norm(dim=-1, keepdim=True)
            text_embs = text_embs.mean(0)
            text_embs /= text_embs.norm(dim=-1, keepdim=True)
            self.text_feature_buffer.update(
                {
                    classname: text_features.detach()
                    for classname, text_features in zip(text_list, text_embs)
                }
            )
            return text_embs  
        else:
            left_text_list = [
                classname for classname in text_list if classname not in self.text_feature_buffer
            ]
            if len(left_text_list) > 0:
                prompts = self.PROMPT_L(imag_fea)
                tokenized_prompts = self.PROMPT_L.tokenized_prompts  
                text_embs = []
                for prompt_i in prompts:
                    text_emb = self.text_encoder(prompt_i, tokenized_prompts)
                    text_embs.append(text_emb)
                text_embs = torch.stack(text_embs, dim=0) 
                text_embs /= text_embs.norm(dim=-1, keepdim=True)
                text_embs = text_embs.mean(0)
                text_embs /= text_embs.norm(dim=-1, keepdim=True)
                self.text_feature_buffer.update(
                    {
                        classname: text_features.detach()
                        for classname, text_features in zip(left_text_list, text_embs)
                    }
                )
                return torch.stack([self.text_feature_buffer[classname] for classname in text_list])

    def visual_feats_to_embs(self, x, normalize: bool = True):
        self.eval()
        x = self.clip_model.visual.trunk.head(x) 
        x = self.clip_model.visual.head(x)
        return F.normalize(x, dim=-1) if normalize else x


    @torch.no_grad()
    def get_visual_feats(self, x):
        self.eval()

        out = {}
        x = self.clip_model.visual.trunk.stem(x)
        out["stem"] = x.contiguous()  
        for i in range(4):
            x = self.clip_model.visual.trunk.stages[i](x)
            out[f"res{i + 2}"] = x.contiguous()  
        last_x = self.clip_model.visual.trunk.norm_pre(x)
        out["clip_vis_dense"] = last_x.contiguous() 

        return out


