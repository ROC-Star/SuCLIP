import torch
from loguru import logger
from torch import nn
import torch.nn.functional as F

from methods.base.base_ops import PixelNormalizer, rescale_2x, resize_to
from methods.ovcoser.layers import ConvMlp, LNConvAct
from methods.ovcoser.loss import edge_dice_loss, l1_ssim_loss, seg_loss
from methods.ovcoser.VLM import CLIP
from methods.ovcoser.modules import TextImgMatchBlock, StructureEnhancementBlock, Refine, CTM, CSM
from methods.ovcoser.TransformerLayers import ContextDecoder



class SuCLIP(nn.Module):
    def __init__(self, classnames, iterations=1,):
        super().__init__()
        assert iterations in [1, 2, 3]
        self.iterations = iterations
        logger.info(f"Current Iteration: {iterations}")
        self.len = len(classnames)

        self.clip = CLIP(classnames=classnames)
        self.normalizer = PixelNormalizer(mean=self.clip.mean, std=self.clip.std)
        self.test_class_embs = None
        self.train_class_embs = None

        self.encoder_dims = [384, 768, 1536, 3072]
        self.hid_dim = 128
        self.tra1 = ConvMlp(self.encoder_dims[0], self.hid_dim)
        self.tra2 = ConvMlp(self.encoder_dims[0], self.hid_dim)
        self.tra3 = ConvMlp(self.encoder_dims[1], self.hid_dim)
        self.tra4 = ConvMlp(self.encoder_dims[2], self.hid_dim)
        self.tra5 = ConvMlp(self.encoder_dims[3], self.hid_dim)

        self.tra6 = ConvMlp(self.encoder_dims[2], self.encoder_dims[1])
        self.tra7 = ConvMlp(self.encoder_dims[1], self.encoder_dims[0])
        self.tra8 = ConvMlp(self.encoder_dims[0], self.encoder_dims[2])

        self.dec5_1 = TextImgMatchBlock(feat_dim=self.hid_dim, guide_dim=self.clip.dim_latent)
        self.dec5 = TextImgMatchBlock(feat_dim=self.hid_dim, guide_dim=self.clip.dim_latent)
        self.dec4 = TextImgMatchBlock(feat_dim=self.hid_dim, guide_dim=self.clip.dim_latent)
        self.dec3 = TextImgMatchBlock(feat_dim=self.hid_dim, guide_dim=self.clip.dim_latent)
        self.dec2 = TextImgMatchBlock(feat_dim=self.hid_dim, guide_dim=self.clip.dim_latent)
        self.dec1 = TextImgMatchBlock(feat_dim=self.hid_dim, guide_dim=self.clip.dim_latent)

        self.cod_head = nn.Sequential(LNConvAct(self.hid_dim, self.hid_dim, 3, 1, 1, act_name="relu"),
                                      nn.Conv2d(self.hid_dim, 1, 3, 1, 1))

        self.mrg3 = StructureEnhancementBlock(self.hid_dim)
        self.mrg2 = StructureEnhancementBlock(self.hid_dim)
        self.mrg1 = StructureEnhancementBlock(self.hid_dim)

        self.dim_latent = self.clip.dim_latent
        self.refine = Refine()
        self.visual_proj = nn.Conv2d(self.encoder_dims[3], self.dim_latent, 1, 1, 0)

        self.context_decoder = ContextDecoder(dim=self.encoder_dims[3], visual_dim=self.dim_latent)
        self.gamma = nn.Parameter(torch.ones(self.clip.dim_latent) * 1e-4)

        self.cod_head_score = nn.Sequential(LNConvAct(self.len, self.len, 3, 1, 1, act_name="relu"),
                                            nn.Conv2d(self.len, 1, 3, 1, 1))

        self.edg_stems = nn.ModuleList([nn.Sequential(LNConvAct(self.hid_dim, self.hid_dim, 3, 1, 1, act_name="relu"),
                                                      nn.Conv2d(self.hid_dim, self.hid_dim, 3, 1, 1)) for _ in
                                        range(3)])
        self.edg_heads = nn.ModuleList([LNConvAct(self.hid_dim, 1, 3, 1, 1, act_name="idy") for _ in range(3)])
        self.dep_stems = nn.ModuleList([nn.Sequential(LNConvAct(self.hid_dim, self.hid_dim, 3, 1, 1, act_name="relu"),
                                                      nn.Conv2d(self.hid_dim, self.hid_dim, 3, 1, 1)) for _ in
                                        range(3)])
        self.dep_heads = nn.ModuleList([LNConvAct(self.hid_dim, 1, 3, 1, 1, act_name="idy") for _ in range(3)])


        self.ctm = CTM(self.encoder_dims[3], self.encoder_dims[3], 0.25)
        self.ctm1 = CTM(self.encoder_dims[0], self.hid_dim, 0.25)
        self.ctm2 = CTM(self.encoder_dims[1], self.hid_dim, 0.25)
        self.ctm3 = CTM(self.encoder_dims[2], self.hid_dim, 0.25)
        self.ctm4 = CTM(self.encoder_dims[3], self.hid_dim, 0.25)
        self.csm1 = CSM(hidden_dim=self.hid_dim, factor=2)
        self.csm2 = CSM(hidden_dim=self.hid_dim, factor=2)
        self.csm3 = CSM(hidden_dim=self.hid_dim, factor=2)
        self.csm4 = CSM(hidden_dim=self.hid_dim, factor=2)

    def get_visual_feats(self, image):
        image = self.normalizer(image)
        image_feats = self.clip.get_visual_feats(image)
        image_stem = rescale_2x(image_feats["stem"]) 
        image_res5 = image_feats["res5"]  
        res5_token_dict = self.vison_token_agg(image_res5)
        image_res5 = self.ctm4(res5_token_dict)

        image_res4 = image_feats["res4"]  
        res4_token_dict = self.vison_token_agg(image_res4)
        image_res4 = self.ctm3(res4_token_dict)

        image_res3 = image_feats["res3"]  
        res3_token_dict = self.vison_token_agg(image_res3)
        image_res3 = self.ctm2(res3_token_dict)

        image_res2 = image_feats["res2"] 
        res2_token_dict = self.vison_token_agg(image_res2)
        image_res2 = self.ctm1(res2_token_dict)

        image_stem = self.tra1(image_stem)

        image_deep = image_feats["clip_vis_dense"] 
        return image_stem, image_res2, image_res3, image_res4, image_res5, image_deep

    def vison_token_agg(self, image_feas):
        B, C, H, W = image_feas.shape
        vision = image_feas.reshape(B, C, H * W).transpose(1, 2)
        B, N, _ = vision.shape
        device = vision.device
        idx_token = torch.arange(N)[None, :].repeat(B, 1).to(device)
        agg_weight = vision.new_ones(B, N, 1)
        token_dict = {'x': vision,
                      'token_num': N,
                      'map_size': [H, W],
                      'init_grid_size': [H, W],
                      'idx_token': idx_token,
                      'agg_weight': agg_weight}
        return token_dict

    def agg_image_feats(self, image):
        image = self.normalizer(image)
        image_feats = self.clip.get_visual_feats(image)
        image_res4 = image_feats["res4"]
        image_res3 = image_feats["res3"]
        image_res2 = image_feats["res2"]

        image_res4_3 = self.tra6(rescale_2x(image_res4, scale_factor=2)) + image_res3
        image_res3_2 = self.tra7(rescale_2x(image_res4_3, scale_factor=2)) + image_res2
        image_res3_2 = self.tra8(resize_to(image_res3_2, (32, 32)))
        return image_res3_2


    def predict_class(self, logits, image_deep, normed_class_embs):
        prob = logits.sigmoid()
        image_embs = resize_to(image_deep, tgt_hw=prob.shape[-2:])

        image_embs = self.refine(prob, image_embs)

        image_embs = image_embs.sum((-1, -2)) / prob.sum((-1, -2))
        image_embs = image_embs[..., None, None]

        normed_image_embs = self.clip.visual_feats_to_embs(image_embs, normalize=True)
        class_logits = normed_image_embs @ normed_class_embs.T  
        class_logits = self.clip.clip_model.logit_scale.exp() * class_logits
        return class_logits

    def body(self, image, normed_class_embs):
        image_stem, image_res2, image_res3, image_res4, image_res5, image_deep = self.get_visual_feats(image)
        logits = {}
        B, C, H, W = image_deep.shape

        image_deep_new = image_deep.reshape(B, C, H * W)
        clss_embes = normed_class_embs.expand(B, -1, -1)
        class_embes = self.context_decoder(clss_embes, image_deep_new)
        class_embes_new = normed_class_embs + self.gamma * class_embes  
        score_map = torch.einsum('bchw,bkc->bkhw', self.visual_proj(image_deep), class_embes_new) 

        score_map = F.interpolate(score_map, size=(image.size()[2], image.size()[3]), mode='bilinear',
                                  align_corners=False)
        score_map = self.cod_head_score(score_map)


        logits["score_map"] = score_map

        x5_1 = self.dec5_1(image_res5, normed_class_embs) 

        logits["seg6"] = self.cod_head(resize_to(x5_1, tgt_hw=(image.size()[2:])))

        x5 = self.dec5(x5_1, normed_class_embs, cls_logits=None, seg_logits=logits["seg6"]) 
        logits["seg5"] = self.cod_head(resize_to(x5, tgt_hw=(image.size()[2:])))


        x4 = image_res4 + rescale_2x(x5)
        x4 = self.csm4(x4)

        x4 = self.dec4(x4, normed_class_embs, cls_logits=None, seg_logits=logits["seg5"])  
        logits["seg4"] = self.cod_head(resize_to(x4, tgt_hw=(image.size()[2:])))

        x3 = image_res3 + rescale_2x(x4)
        x3 = self.csm3(x3)


        x3 = self.dec3(x3, normed_class_embs, cls_logits=None, seg_logits=logits["seg4"])
        edg_feat3 = self.edg_stems[2](x3)
        dep_feat3 = self.dep_stems[2](x3)
        x3 = self.mrg3(x3, [edg_feat3, dep_feat3])
        logits["seg3"] = self.cod_head(resize_to(x3, tgt_hw=(image.size()[2:])))

        x2 = image_res2 + rescale_2x(x3)
        x2 = self.csm2(x2)


        x2 = self.dec2(x2, normed_class_embs, cls_logits=None, seg_logits=logits["seg3"])
        edg_feat2 = self.edg_stems[1](x2)
        dep_feat2 = self.dep_stems[1](x2)
        x2 = self.mrg2(x2, [edg_feat2, dep_feat2])
        logits["seg2"] = self.cod_head(resize_to(x2, tgt_hw=(image.size()[2:])))

        x1 = image_stem + rescale_2x(x2)
        x1 = self.csm1(x1)


        x1 = self.dec1(x1, normed_class_embs, cls_logits=None, seg_logits=logits["seg2"])
        edg_feat1 = self.edg_stems[0](x1)
        dep_feat1 = self.dep_stems[0](x1)
        x1 = self.mrg1(x1, [edg_feat1, dep_feat1])

        seg_logits = self.cod_head(rescale_2x(x1))
        cls_logits = self.predict_classr(seg_logits, image_deep, normed_class_embs)
        logits["seg"] = seg_logits
        logits["cls"] = cls_logits
        logits["dep3"] = self.dep_heads[2](dep_feat3)
        logits["dep2"] = self.dep_heads[1](dep_feat2)
        logits["dep1"] = self.dep_heads[0](dep_feat1)
        logits["edg3"] = self.edg_heads[2](edg_feat3)
        logits["edg2"] = self.edg_heads[1](edg_feat2)
        logits["edg1"] = self.edg_heads[0](edg_feat1)
        return logits

    def train_forward(self, data, gt_classes, class_names: list, **kwargs):
        image = data["image"]
        depth = data["depth"]
        mask = data["mask"]

        _, _, _, _, _, last_image_deep = self.get_visual_feats(image)

        last_image_deep = last_image_deep / last_image_deep.norm(dim=-1, keepdim=True)
        last_image_deep_dict = self.vison_token_agg(last_image_deep)
        last_vision_map_new = self.ctm(last_image_deep_dict)

        last_vision_map_new = self.clip.visual_feats_to_embs(last_image_deep, normalize=True)  
        if self.train_class_embs is None:
            self.train_class_embs = self.clip.get_text_embs_by_template(class_names, last_vision_map_new,
                                                                        with_trainable_params=True)
        normed_class_embs = self.train_class_embs
        losses = []
        loss_str = []

        logits_dict = self.body(image, normed_class_embs)
        with torch.no_grad():
            edge_ks = 5
            eroded_mask = -F.max_pool2d(-mask, kernel_size=edge_ks, stride=1, padding=edge_ks // 2)
            dilated_mask = F.max_pool2d(mask, kernel_size=edge_ks, stride=1, padding=edge_ks // 2)
            edge = dilated_mask - eroded_mask
            edge = edge.gt(0).float()
        logits_dict["edge"] = edge

        depth_loss = l1_ssim_loss(logits=logits_dict["dep3"], mask=depth) + l1_ssim_loss(logits=logits_dict["dep2"],
                                                                                         mask=depth) + l1_ssim_loss(
            logits=logits_dict["dep1"], mask=depth)
        losses.append(depth_loss)

        edge_loss = edge_dice_loss(logits=logits_dict["edg3"], edge=edge) + edge_dice_loss(logits=logits_dict["edg2"],
                                                                                           edge=edge) + edge_dice_loss(
            logits=logits_dict["edg1"], edge=edge)
        losses.append(edge_loss)
        seg_logits = logits_dict["seg"]
        seg_logits2 = logits_dict["seg2"]
        seg_logits3 = logits_dict["seg3"]
        seg_logits4 = logits_dict["seg4"]
        seg_logits5 = logits_dict["seg5"]
        seg_logits6 = logits_dict["seg6"]
        seg_logits7 = logits_dict["score_map"]

        segl = (seg_loss(logits=seg_logits, mask=mask) + seg_loss(logits=seg_logits2, mask=mask)
                + seg_loss(logits=seg_logits3, mask=mask) + seg_loss(logits=seg_logits4, mask=mask)
                + seg_loss(logits=seg_logits5, mask=mask) + seg_loss(logits=seg_logits6, mask=mask)+ seg_loss(logits=seg_logits7, mask=mask))
        losses.append(segl)
        loss_str.append(f"segl: {segl.item():.5f}")

        return dict(
            vis={k: v if k == "edge" else v.sigmoid() for k, v in logits_dict.items() if not k.startswith("cls")},
            loss=sum(losses),
            loss_str=" ".join(loss_str),
        )

    def test_forward(self, data, gt_classes, class_names: list, **kwargs):
        image = data["image"]
        # image = data
        _, _, _, _, _, last_image_deep = self.get_visual_feats(image)

        last_image_deep = last_image_deep / last_image_deep.norm(dim=-1, keepdim=True)
        last_vision_map_new = self.vison_token_agg(last_image_deep)
        last_vision_map_new = self.clip.visual_feats_to_embs(last_image_deep, normalize=True) 
        if self.test_class_embs is None:
            self.test_class_embs = self.clip.get_text_embs_by_template(class_names, last_vision_map_new,
                                                                       with_trainable_params=False)
        normed_class_embs = self.test_class_embs

        logits_dict = self.body(image, normed_class_embs)
        seg_logits = logits_dict["seg"]
        cls_logits = logits_dict["cls"]

        cls_id_per_image = torch.argmax(cls_logits, dim=-1)
        pred_classes = [class_names[i] for i in cls_id_per_image]
        return dict(prob=seg_logits.sigmoid(), classes=pred_classes)

    def forward(self, *arg, **kwargs):
        if self.training:
            return self.train_forward(*arg, **kwargs)
        else:
            return self.test_forward(*arg, **kwargs)

    def get_grouped_params(self):
        param_groups = {"pretrained": [], "fixed": [], "retrained": []}
       
        for name, param in self.named_parameters():
            if name.startswith("clip.PROMPT_L."):
                param.requires_grad = True
                param_groups["retrained"].append(param)
            elif name.startswith("clip."):
                param.requires_grad = False
                param_groups["pretrained"].append(param)
            if name.startswith("clip."):
                param.requires_grad = False
                param_groups["pretrained"].append(param)
            else:
                param.requires_grad = True
                param_groups["retrained"].append(param)
        logger.info(
            f"Parameter Groups:{{"
            f"Pretrained: {len(param_groups['pretrained'])}, "
            f"Fixed: {len(param_groups['fixed'])}, "
            f"ReTrained: {len(param_groups['retrained'])}}}"
        )
        return param_groups
